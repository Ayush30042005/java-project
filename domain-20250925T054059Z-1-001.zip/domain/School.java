package edu.ccrm.domain;

public enum School {
    SCOPE, // School of Computing Science and Engineering
    SENSE, // School of Electrical & Electronics Engineering
    SMEC,  // School of Mechanical Engineering
    VISH,  // VIT International School Bhopal
    LAW    // VIT School of Law
}