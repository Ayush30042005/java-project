package edu.ccrm.domain;

public class CourseCode {
    
}
