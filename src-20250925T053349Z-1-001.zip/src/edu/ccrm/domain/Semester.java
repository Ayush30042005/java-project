package edu.ccrm.domain;

public enum Semester {
    FALL,
    WINTER,
    SUMMER
}